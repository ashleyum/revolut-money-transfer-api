package main.java.com.revolut.moneytransfer.exception;

public class IncorrectInputException extends Exception {

	private static final long serialVersionUID = 4735363903732061763L;

	public IncorrectInputException(String message) {
		super(message);
	}

}
